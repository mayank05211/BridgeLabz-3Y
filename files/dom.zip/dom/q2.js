// Q2 - Live Character Counter with Warning Behavior

const MAX_CHARACTERS = 100;
const WARNING_THRESHOLD = 20;

const messageBox = document.getElementById("message");
const counterLabel = document.getElementById("counter");
const resetButton = document.getElementById("reset-btn");

// Recalculate remaining characters and update text + colour class
function updateCounter() {
  const remainingCharacters = MAX_CHARACTERS - messageBox.value.length;
  counterLabel.textContent = `${remainingCharacters} characters left`;

  counterLabel.classList.remove("warning", "danger");
  if (remainingCharacters <= 0) {
    counterLabel.classList.add("danger");        // red at 0
  } else if (remainingCharacters <= WARNING_THRESHOLD) {
    counterLabel.classList.add("warning");       // yellow at 20 or fewer
  }
}

// Block typing once the limit is reached
messageBox.addEventListener("keydown", (event) => {
  const isLimitReached = messageBox.value.length >= MAX_CHARACTERS;
  // key.length === 1 means a printable character; Enter also adds a character
  const addsCharacter = (event.key.length === 1 || event.key === "Enter")
    && !event.ctrlKey && !event.metaKey;
  // Allow replacing selected text even at the limit
  const hasSelection = messageBox.selectionStart !== messageBox.selectionEnd;

  if (isLimitReached && addsCharacter && !hasSelection) {
    event.preventDefault();
  }
});

// Pasted text can bypass keydown, so trim any overflow here
messageBox.addEventListener("input", () => {
  if (messageBox.value.length > MAX_CHARACTERS) {
    messageBox.value = messageBox.value.slice(0, MAX_CHARACTERS);
  }
  updateCounter();
});

resetButton.addEventListener("click", () => {
  messageBox.value = "";
  updateCounter();
  messageBox.focus();
});

updateCounter();
