// Q5 - Image Gallery with Modal Preview
// Images are generated as inline SVG so the demo works offline.

const gallery = document.getElementById("gallery");
const modal = document.getElementById("modal");
const modalContent = document.getElementById("modal-content");
const modalImage = document.getElementById("modal-image");
const modalCaption = document.getElementById("modal-caption");

const IMAGE_COLORS = ["#e76f51", "#2a9d8f", "#e9c46a", "#264653", "#8e7dbe", "#f4a261"];

// Build a data-URI SVG with a colour and a number
function createImageSource(imageNumber, color, width, height) {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}">
    <rect width="100%" height="100%" fill="${color}"/>
    <circle cx="${width * 0.75}" cy="${height * 0.3}" r="${height * 0.12}" fill="rgba(255,255,255,0.5)"/>
    <text x="50%" y="58%" font-family="sans-serif" font-size="${height * 0.3}" fill="#fff" text-anchor="middle">${imageNumber}</text>
  </svg>`;
  return "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svg);
}

// Create 6 thumbnails
IMAGE_COLORS.forEach((color, index) => {
  const thumbnail = document.createElement("img");
  thumbnail.src = createImageSource(index + 1, color, 400, 300);
  thumbnail.alt = `Image ${index + 1}`;
  // Remember how to build the big version of this image
  thumbnail.dataset.imageNumber = index + 1;
  thumbnail.dataset.color = color;
  gallery.appendChild(thumbnail);
});

function openModal(imageNumber, color) {
  modalImage.src = createImageSource(imageNumber, color, 1200, 800);
  modalImage.alt = `Image ${imageNumber} (large)`;
  modalCaption.textContent = `Image ${imageNumber}`;
  modal.hidden = false;
}

function closeModal() {
  modal.hidden = true;
}

// Event delegation: one listener on the grid
gallery.addEventListener("click", (event) => {
  const clickedImage = event.target.closest("img");
  if (clickedImage) openModal(clickedImage.dataset.imageNumber, clickedImage.dataset.color);
});

// Click on the dark backdrop closes the modal
modal.addEventListener("click", closeModal);

// Click inside the modal box must NOT bubble up to the backdrop
modalContent.addEventListener("click", (event) => {
  event.stopPropagation();
});

// Bonus: Escape key closes it too
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape") closeModal();
});
