// Q1 - Dynamic Product List Manager (Event Delegation)

const productInput = document.getElementById("product-input");
const addButton = document.getElementById("add-btn");
const productList = document.getElementById("product-list");

// Tracks the <li> currently in edit mode (null when none)
let currentlyEditingItem = null;

// Builds one product <li> with text + Edit/Delete buttons
function createProductItem(productName) {
  const listItem = document.createElement("li");
  listItem.innerHTML = `
    <span class="item-text"></span>
    <button class="edit-btn secondary" data-action="edit">Edit</button>
    <button class="delete-btn danger" data-action="delete">Delete</button>`;
  // textContent avoids injecting HTML from user input
  listItem.querySelector(".item-text").textContent = productName;
  return listItem;
}

function addProduct() {
  const productName = productInput.value.trim();
  if (!productName) return;
  productList.appendChild(createProductItem(productName));
  productInput.value = "";
  productInput.focus();
}

// Swap the text <span> for an <input> so it can be edited inline
function startEditing(listItem) {
  // Only one item may be edited at a time: save the previous one first
  if (currentlyEditingItem) saveEditing(currentlyEditingItem);

  const textSpan = listItem.querySelector(".item-text");
  const editInput = document.createElement("input");
  editInput.type = "text";
  editInput.className = "item-text";
  editInput.value = textSpan.textContent;
  listItem.replaceChild(editInput, textSpan);

  listItem.classList.add("editing");
  listItem.querySelector(".edit-btn").textContent = "Save";
  editInput.focus();
  currentlyEditingItem = listItem;
}

// Swap the <input> back to a <span>, keeping the new text (or the old if blank)
function saveEditing(listItem) {
  const editInput = listItem.querySelector("input.item-text");
  if (!editInput) return;

  const textSpan = document.createElement("span");
  textSpan.className = "item-text";
  textSpan.textContent = editInput.value.trim() || editInput.defaultValue;
  listItem.replaceChild(textSpan, editInput);

  listItem.classList.remove("editing");
  listItem.querySelector(".edit-btn").textContent = "Edit";
  if (currentlyEditingItem === listItem) currentlyEditingItem = null;
}

// ONE click listener on the parent <ul> handles every Edit/Delete button
productList.addEventListener("click", (event) => {
  const button = event.target.closest("button[data-action]");
  if (!button) return;
  const listItem = button.closest("li");

  if (button.dataset.action === "delete") {
    if (currentlyEditingItem === listItem) currentlyEditingItem = null;
    listItem.remove();
  } else if (button.dataset.action === "edit") {
    // The same button toggles between Edit and Save
    listItem === currentlyEditingItem ? saveEditing(listItem) : startEditing(listItem);
  }
});

// Enter key inside the inline input saves it (delegated as well)
productList.addEventListener("keydown", (event) => {
  if (event.key === "Enter" && event.target.matches("input.item-text")) {
    saveEditing(event.target.closest("li"));
  }
});

// Click anywhere outside the item being edited -> auto-save
document.addEventListener("click", (event) => {
  if (currentlyEditingItem && !currentlyEditingItem.contains(event.target)) {
    saveEditing(currentlyEditingItem);
  }
});

addButton.addEventListener("click", addProduct);
productInput.addEventListener("keydown", (event) => {
  if (event.key === "Enter") addProduct();
});
