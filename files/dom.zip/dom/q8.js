// Q8 - Custom Dropdown Using Only JavaScript (no <select>)

const dropdown = document.getElementById("dropdown");
const dropdownButton = document.getElementById("dropdown-btn");
const dropdownMenu = document.getElementById("dropdown-menu");

function setMenuOpen(isOpen) {
  dropdownMenu.hidden = !isOpen;
  dropdownButton.setAttribute("aria-expanded", String(isOpen));
}

// Button toggles the menu
dropdownButton.addEventListener("click", () => {
  setMenuOpen(dropdownMenu.hidden);
});

// Clicking an option updates the button text and closes the menu
dropdownMenu.addEventListener("click", (event) => {
  const chosenOption = event.target.closest("li");
  if (!chosenOption) return;
  dropdownButton.textContent = chosenOption.textContent;
  setMenuOpen(false);
});

// Closing mechanism uses the CAPTURING phase (third argument = true).
// Capturing listeners run before any target/bubbling listeners, so the
// dropdown closes even if another element calls stopPropagation().
document.addEventListener(
  "click",
  (event) => {
    if (!dropdown.contains(event.target)) setMenuOpen(false);
  },
  true
);
