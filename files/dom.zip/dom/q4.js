// Q4 - Theme Switcher Using Attribute Manipulation

const themeButtons = document.querySelectorAll(".theme-btn");
const currentThemeLabel = document.getElementById("current-theme");
const pageBody = document.body;

function applyTheme(themeName) {
  // Class applied with setAttribute (replaces the whole class attribute)
  pageBody.setAttribute("class", `theme-${themeName}`);
  // Current theme saved in a custom attribute: data-theme="dark"
  pageBody.setAttribute("data-theme", themeName);

  currentThemeLabel.textContent =
    `Current theme: ${pageBody.getAttribute("data-theme")}`;
}

themeButtons.forEach((button) => {
  button.addEventListener("click", () => applyTheme(button.dataset.themeName));
});

applyTheme("light"); // default theme
