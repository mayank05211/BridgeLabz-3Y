// Q3 - Multi-Step Form with Next/Back & Validation

const steps = document.querySelectorAll(".step");
const stepIndicator = document.getElementById("step-indicator");
const stepError = document.getElementById("step-error");
const backButton = document.getElementById("back-btn");
const nextButton = document.getElementById("next-btn");
const formArea = document.getElementById("form-area");
const summaryBox = document.getElementById("summary");

let currentStepIndex = 0;

// One validator per step: returns an error message, or "" when valid
const validators = [
  (value) => (value.trim().length >= 2 ? "" : "Enter your name (at least 2 characters)."),
  (value) => (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value) ? "" : "Enter a valid email address."),
  (value) => (value.length >= 6 ? "" : "Password must be at least 6 characters.")
];

// Show only the current step and update the UI around it
function showStep(index) {
  steps.forEach((step, stepPosition) => {
    step.hidden = stepPosition !== index;
  });
  stepIndicator.textContent = `Step ${index + 1} of ${steps.length}`;
  backButton.disabled = index === 0;
  nextButton.textContent = index === steps.length - 1 ? "Finish" : "Next";
  stepError.textContent = "";
  steps[index].querySelector("input").focus();
}

function showSummary() {
  formArea.hidden = true;
  stepIndicator.hidden = true;
  summaryBox.hidden = false;
  summaryBox.innerHTML = `
    <h2>Summary</h2>
    <p><strong>Name:</strong> <span id="s-name"></span></p>
    <p><strong>Email:</strong> <span id="s-email"></span></p>
    <p><strong>Password:</strong> ${"•".repeat(document.getElementById("password").value.length)}</p>`;
  // textContent keeps user input from being parsed as HTML
  document.getElementById("s-name").textContent = document.getElementById("name").value.trim();
  document.getElementById("s-email").textContent = document.getElementById("email").value.trim();
}

nextButton.addEventListener("click", () => {
  const input = steps[currentStepIndex].querySelector("input");
  const errorMessage = validators[currentStepIndex](input.value);

  if (errorMessage) {                 // invalid -> stay on this step
    stepError.textContent = errorMessage;
    return;
  }
  if (currentStepIndex === steps.length - 1) {
    showSummary();                    // all 3 steps done
  } else {
    currentStepIndex++;
    showStep(currentStepIndex);
  }
});

backButton.addEventListener("click", () => {
  if (currentStepIndex > 0) {
    currentStepIndex--;
    showStep(currentStepIndex);
  }
});

// Enter key behaves like "Next"
formArea.addEventListener("keydown", (event) => {
  if (event.key === "Enter") nextButton.click();
});

showStep(0);
