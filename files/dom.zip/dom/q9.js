// Q9 - Form Submit Blocker with preventDefault() and Live Errors

const form = document.getElementById("signup-form");
const successMessage = document.getElementById("success-message");

// Validation rule per field: returns "" when valid, else an error message
const validationRules = {
  name: (value) => (value.trim() ? "" : "Name is required."),
  email: (value) => {
    if (!value.trim()) return "Email is required.";
    return value.includes("@") ? "" : "Email must contain @.";
  },
  password: (value) => (value.length >= 6 ? "" : "Password must be at least 6 characters.")
};

// Show or clear the error text under one field
function showFieldError(fieldId, message) {
  const errorElement = form.querySelector(`[data-error-for="${fieldId}"]`);
  const inputElement = document.getElementById(fieldId);
  errorElement.textContent = message;
  inputElement.classList.toggle("invalid", Boolean(message));
}

// Validate one field; returns true if valid
function validateField(fieldId) {
  const message = validationRules[fieldId](document.getElementById(fieldId).value);
  showFieldError(fieldId, message);
  return message === "";
}

form.addEventListener("submit", (event) => {
  event.preventDefault(); // always stop the real page submission

  // Validate every field (map, not .every, so ALL errors show at once)
  const results = Object.keys(validationRules).map(validateField);
  const isFormValid = results.every(Boolean);

  successMessage.hidden = !isFormValid;
  if (isFormValid) form.reset();
});

// Live feedback: re-validate a field as the user corrects it,
// but only once it is already showing an error (so errors disappear automatically)
form.addEventListener("input", (event) => {
  const fieldId = event.target.id;
  if (!validationRules[fieldId]) return;
  successMessage.hidden = true;
  if (event.target.classList.contains("invalid")) validateField(fieldId);
});
