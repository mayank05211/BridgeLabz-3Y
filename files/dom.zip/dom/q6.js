// Q6 - Real-Time Table Filter Using the input Event

const searchBox = document.getElementById("search");
const tableRows = document.querySelectorAll("#students tbody tr");
const noResultsMessage = document.getElementById("no-results");

// Runs on every keystroke
function filterTable() {
  // Lower-casing both sides makes the search case-insensitive
  const searchTerm = searchBox.value.trim().toLowerCase();
  let visibleRowCount = 0;

  tableRows.forEach((row) => {
    const rowText = row.textContent.toLowerCase();
    const isMatch = rowText.includes(searchTerm);
    row.hidden = !isMatch;
    if (isMatch) visibleRowCount++;
  });

  // Show the message only when nothing matches
  noResultsMessage.hidden = visibleRowCount > 0;
}

searchBox.addEventListener("input", filterTable);
