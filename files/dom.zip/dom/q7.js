// Q7 - Mouse Path & Coordinates Logger

const box = document.getElementById("box");
const coordsLabel = document.getElementById("coords");

// Live clientX / clientY while the mouse moves inside the box
box.addEventListener("mousemove", (event) => {
  coordsLabel.textContent = `clientX: ${event.clientX}, clientY: ${event.clientY}`;
});

box.addEventListener("mouseleave", () => {
  coordsLabel.textContent = "clientX: -, clientY: -";
});

// Double-click drops a red dot at the click position
box.addEventListener("dblclick", (event) => {
  // clientX/Y are relative to the window; the dot is positioned relative
  // to the box, so subtract the box's own position (and its border).
  const boxBounds = box.getBoundingClientRect();
  const dotX = event.clientX - boxBounds.left - box.clientLeft;
  const dotY = event.clientY - boxBounds.top - box.clientTop;

  const dot = document.createElement("div");
  dot.className = "dot";
  dot.style.left = `${dotX}px`;
  dot.style.top = `${dotY}px`;
  box.appendChild(dot);
});
