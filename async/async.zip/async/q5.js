// Q5 - Frontend Rush: Avoiding Callback Hell

// ===================== PART 1: Nested callbacks =====================
// Each stage takes 1 second and logs its step, then calls the next one.
function runStageWithCallback(stageName, callback) {
  setTimeout(() => {
    console.log(`[callbacks] ${stageName}`);
    callback();
  }, 1000);
}

function runPipelineWithCallbacks(onFinished) {
  // The "pyramid of doom": every new stage pushes the code further right
  runStageWithCallback("design", () => {
    runStageWithCallback("build", () => {
      runStageWithCallback("test", () => {
        runStageWithCallback("deploy", () => {
          runStageWithCallback("celebrate", () => {
            onFinished();
          });
        });
      });
    });
  });
}

// ===================== PART 2: async/await =====================
function runStageWithPromise(stageName) {
  return new Promise((resolve) => {
    setTimeout(() => {
      console.log(`[async/await] ${stageName}`);
      resolve();
    }, 1000);
  });
}

/*
  Why async/await is more readable:
  - Code reads top to bottom like synchronous code, in the order it runs.
  - No nesting: adding a stage is one new line, not one more indent level.
  - Error handling is a single try/catch instead of an error check in every callback.
  - Easy to use loops and conditions between steps.
*/
async function runPipelineWithAsyncAwait() {
  try {
    await runStageWithPromise("design");
    await runStageWithPromise("build");
    await runStageWithPromise("test");
    await runStageWithPromise("deploy");
    await runStageWithPromise("celebrate");
    console.log("Pipeline finished (async/await)");
  } catch (error) {
    console.error(`Pipeline failed: ${error.message}`);
  }
}

// Run the callback version first, then the async/await version
console.log("--- Callback hell version ---");
runPipelineWithCallbacks(() => {
  console.log("Pipeline finished (callbacks)\n");
  console.log("--- async/await version ---");
  runPipelineWithAsyncAwait();
});
