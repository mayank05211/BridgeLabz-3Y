// Q10 - The Final Delivery: Async Pipeline Debugger

const FAILURE_CHANCE = 0.15; // each step fails ~15% of the time

// Random delay between 1000 and 2000 ms
function getRandomDelay() {
  return 1000 + Math.floor(Math.random() * 1001);
}

// Builds a step: waits a random 1-2s, then resolves with a message or rejects.
// setTimeout hands the waiting to the timer system; the call stack is free
// meanwhile, and when the timer fires its callback is queued as a macrotask.
function createStep(successMessage, failureMessage) {
  return () => new Promise((resolve, reject) => {
    setTimeout(() => {
      if (Math.random() < FAILURE_CHANCE) {
        reject(new Error(failureMessage));
      } else {
        resolve(successMessage);
      }
    }, getRandomDelay());
  });
}

const takeOrder = createStep("Step 1: Order taken", "Order could not be taken");
const prepare = createStep("Step 2: Food prepared", "Food could not be prepared");
const pack = createStep("Step 3: Package ready", "Packing failed");
const dispatch = createStep("Step 4: Out for delivery", "Dispatch failed");
const deliver = createStep("Delivery completed!", "Delivery failed");

/*
  Control flow of runPipeline():
  - `await` pauses ONLY this async function. The event loop keeps running
    other work while a step's timer counts down.
  - When the promise settles, the continuation is queued as a microtask and
    the function resumes right after the await.
  - A rejected promise makes `await` throw, so the catch block runs and the
    remaining steps are skipped.
*/
async function runPipeline() {
  console.log("Start Pipeline");
  try {
    console.log(await takeOrder());
    console.log(await prepare());
    console.log(await pack());
    console.log(await dispatch());
    console.log(await deliver());
  } catch (error) {
    console.error(`Reason: ${error.message}`);
    console.error("Pipeline failed!");
  }
}

runPipeline();
