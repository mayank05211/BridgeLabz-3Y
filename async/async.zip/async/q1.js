// Q1 - The Startup Morning: Async Coffee Maker (Promise chaining)

// Returns a random whole number of milliseconds between 1000 and 2000
function getRandomDelay() {
  return 1000 + Math.floor(Math.random() * 1001);
}

// Generic step helper: waits 1-2 seconds, then resolves with a message.
// ~20% of the time it rejects to simulate a failure (Math.random()).
function runCoffeeStep(stepName, successMessage) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const didFail = Math.random() < 0.2;
      if (didFail) {
        reject(new Error(`${stepName} failed`));
      } else {
        console.log(successMessage);
        resolve(successMessage);
      }
    }, getRandomDelay());
  });
}

const boilWater = () => runCoffeeStep("Boiling water", "Step 1: Water boiled");
const brewCoffee = () => runCoffeeStep("Brewing coffee", "Step 2: Coffee brewed");
const pourIntoCup = () => runCoffeeStep("Pouring coffee", "Step 3: Coffee poured into cup");

console.log("Starting the coffee process...");

// Each .then() waits for the previous promise, so the steps run in order.
boilWater()
  .then(() => brewCoffee())
  .then(() => pourIntoCup())
  .then(() => console.log("Coffee ready for the team!"))
  // A rejection in ANY step skips the remaining .then() calls and lands here.
  .catch((error) => console.error(`Coffee process stopped: ${error.message}`));
