// Q3 - Bug Tracker: Callback to Promise Migration

// ---- Original callback-based version (kept for reference) ----
function fetchBugs(callback) {
  setTimeout(() => callback(["UI glitch", "API timeout", "Login failure"]), 1000);
}

// ---- Promise-based version ----
// simulateApiFailure is a boolean flag: when true the "API" rejects.
function getBugs(simulateApiFailure) {
  return new Promise((resolve, reject) => {
    // Reuse the old function and wrap its callback in a Promise
    fetchBugs((bugs) => {
      if (simulateApiFailure) {
        reject(new Error("API request failed: could not load bugs"));
      } else {
        resolve(bugs);
      }
    });
  });
}

// Random boolean: roughly 30% chance of failure (change to true/false to force)
const shouldSimulateFailure = Math.random() < 0.3;
console.log(`Fetching bugs... (simulate failure: ${shouldSimulateFailure})`);

getBugs(shouldSimulateFailure)
  .then((bugs) => {
    // Turn the array into rows so console.table shows an ID and a description
    const bugRows = bugs.map((bugName, index) => ({ ID: index + 1, Bug: bugName }));
    console.table(bugRows);
  })
  .catch((error) => console.error(error.message));
