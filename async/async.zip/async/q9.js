// Q9 - Debugging the Event Loop

/*
  PREDICTED OUTPUT (written before running):
    1. Script start        (synchronous)
    2. Script end          (synchronous)
    3. Promise callback    (microtask)
    4. Timeout callback    (macrotask)

  ACTUAL OUTPUT (after running):
    Script start
    Script end
    Promise callback
    Timeout callback
  -> Matches the prediction.

  WHY promises run before setTimeout:
  - Synchronous code runs first on the call stack ("Script start", "Script end").
  - .then() callbacks are microtasks. After the stack empties, the event loop
    runs ALL queued microtasks first.
  - setTimeout callbacks are macrotasks. Even with 0 ms they go to the timer
    queue and run only after the microtask queue is empty.
*/

console.log("Script start");
setTimeout(() => console.log("Timeout callback"), 0);
Promise.resolve().then(() => console.log("Promise callback"));
console.log("Script end");
