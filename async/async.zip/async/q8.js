// Q8 - Order Processing Flow: Async Retry Mechanism

const MAX_ATTEMPTS = 3;

// Fails 50% of the time
function submitOrder() {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (Math.random() < 0.5) {
        resolve("Order submitted");
      } else {
        reject(new Error("Server error"));
      }
    }, 500);
  });
}

async function processOrder() {
  for (let attemptNumber = 1; attemptNumber <= MAX_ATTEMPTS; attemptNumber++) {
    try {
      const result = await submitOrder();
      console.log(`Attempt ${attemptNumber}: Success`);
      return result;                      // success: stop retrying
    } catch (error) {
      console.log(`Attempt ${attemptNumber}: Failed`);
      // loop continues to the next attempt
    }
  }
  // Loop finished without returning, so every attempt failed
  throw new Error("Order could not be processed");
}

// Handle the final failure gracefully
async function main() {
  try {
    const result = await processOrder();
    console.log(`Final result: ${result}`);
  } catch (error) {
    console.error(error.message);
  }
}

main();
