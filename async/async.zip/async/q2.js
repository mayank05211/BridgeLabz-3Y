// Q2 - Task Scheduler: Micro vs Macro Challenge

console.log("Start");

// Macrotask: goes to the macrotask (timer) queue, even with 0 ms delay
setTimeout(() => {
  console.log("Macrotask: setTimeout callback");
}, 0);

// Microtask: the promise is already resolved, so .then() queues a microtask
Promise.resolve().then(() => {
  console.log("Microtask: Promise.then callback");
});

// Synchronous log: runs immediately on the call stack
console.log("Synchronous log");

console.log("End");

/*
  Actual output order:
    Start
    Synchronous log
    End
    Microtask: Promise.then callback
    Macrotask: setTimeout callback

  WHY microtasks run before macrotasks:
  1. All synchronous code runs first, until the call stack is empty.
  2. The event loop then drains the ENTIRE microtask queue (promise callbacks,
     queueMicrotask) before it moves on.
  3. Only after that does it take ONE macrotask (setTimeout, setInterval,
     I/O, UI events), and it drains microtasks again after every macrotask.
  So even setTimeout(..., 0) has to wait for the pending promise callbacks.
*/
