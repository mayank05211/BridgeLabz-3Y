// Q6 - E-Commerce Dashboard: Product Card Fetcher
// Works in Node.js 18+ (console output) and in the browser (console + cards).

const PRODUCTS_API_URL = "https://fakestoreapi.com/products";

// Fetch the product list; throws if the request or response is bad
async function fetchProducts() {
  const response = await fetch(PRODUCTS_API_URL);
  if (!response.ok) {
    throw new Error(`Request failed with status ${response.status}`);
  }
  return response.json();
}

// Console output for one product
function logProduct(product) {
  console.log(`Product: ${product.title}`);
  console.log(`Price: $${product.price}`);
  console.log(`Image: ${product.image}`);
  console.log(""); // blank line between products
}

// BONUS: build an HTML card using createElement (browser only)
function createProductCard(product) {
  const card = document.createElement("div");
  card.className = "product-card";

  const image = document.createElement("img");
  image.src = product.image;
  image.alt = product.title;

  const title = document.createElement("h3");
  title.textContent = product.title;

  const price = document.createElement("p");
  price.className = "price";
  price.textContent = `$${product.price}`;

  card.append(image, title, price);
  return card;
}

async function showProducts() {
  // "document" only exists in browsers, so Node skips the DOM part
  const productContainer = typeof document !== "undefined"
    ? document.getElementById("product-container")
    : null;
  const errorMessage = typeof document !== "undefined"
    ? document.getElementById("error-message")
    : null;

  try {
    const products = await fetchProducts();

    products.forEach((product) => {
      logProduct(product);
      if (productContainer) productContainer.appendChild(createProductCard(product));
    });
  } catch (error) {
    console.error(`Error details: ${error.message}`);
    const userMessage = "Failed to load products. Please try again.";
    console.log(userMessage);
    if (errorMessage) errorMessage.textContent = userMessage;
  }
}

showProducts();
