// Q7 - The Lazy Loader: Promise.allSettled()

function loadProfile() { return new Promise(r => setTimeout(() => r("Profile Loaded"), 2000)); }
function loadPosts() { return new Promise(r => setTimeout(() => r("Posts Loaded"), 1500)); }
function loadMessages() { return new Promise(r => setTimeout(() => r("Messages Loaded"), 1000)); }

// Wraps a loader so it randomly rejects instead of resolving
function makeRejecting(loaderName, loaderFunction) {
  return () => loaderFunction().then(() => {
    throw new Error(`${loaderName} failed to load`);
  });
}

async function loadDashboard() {
  const moduleNames = ["Profile", "Posts", "Messages"];
  const loaders = [loadProfile, loadPosts, loadMessages];

  // Randomly pick ONE module to reject
  const failingIndex = Math.floor(Math.random() * loaders.length);
  loaders[failingIndex] = makeRejecting(moduleNames[failingIndex], loaders[failingIndex]);

  const startTime = Date.now();

  // allSettled never rejects: it waits for every promise and reports each outcome
  const results = await Promise.allSettled(loaders.map((load) => load()));

  const totalTimeMs = Date.now() - startTime;

  results.forEach((result, index) => {
    if (result.status === "fulfilled") {
      console.log(`${moduleNames[index]}: SUCCESS -> ${result.value}`);
    } else {
      console.log(`${moduleNames[index]}: FAILED -> ${result.reason.message}`);
    }
  });

  // Modules load in parallel, so total time ~ the slowest one (about 2000 ms)
  console.log(`Total time taken: ${totalTimeMs} ms`);
}

loadDashboard();
