// Q4 - DevOps Delay: Async Timeout Race

// Creates a "server" promise that responds after delayMs.
// It randomly fails (~20%) using Math.random().
function deployToServer(serverName, delayMs) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (Math.random() < 0.2) {
        reject(new Error(`${serverName} failed to respond`));
      } else {
        resolve(`${serverName} responded after ${delayMs / 1000}s`);
      }
    }, delayMs);
  });
}

// Both deployments start NOW and run concurrently
const serverA = deployToServer("Server A", 2000);
const serverB = deployToServer("Server B", 3000);

// Promise.all: waits for BOTH; rejects as soon as one fails
Promise.all([serverA, serverB])
  .then((responses) => {
    console.log("Deployment completed for all servers");
    console.log(responses);
  })
  .catch((error) => console.error(`Promise.all error: ${error.message}`));

// Promise.race: settles with whichever promise settles FIRST
Promise.race([serverA, serverB])
  .then((fastestResponse) => console.log("Fastest response:", fastestResponse))
  .catch((error) => console.error(`Promise.race error: ${error.message}`));
